(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_75e0ff4d._.js",
  "static/chunks/node_modules_next_dist_9e75e258._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_56b6fd65._.js",
  "static/chunks/node_modules_motion-dom_dist_es_db3b61fc._.js",
  "static/chunks/node_modules_framer-motion_dist_es_1a39b1db._.js",
  "static/chunks/node_modules_5c562180._.js"
],
    source: "dynamic"
});
